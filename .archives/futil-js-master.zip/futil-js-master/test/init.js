global.__VERSION__ = '1.0.0'
