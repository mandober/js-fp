module.exports = {
  extends: 'smartprocure',
  parser: 'babel-eslint',
  parserOptions: {
    sourceType: 'module'
  }
}
